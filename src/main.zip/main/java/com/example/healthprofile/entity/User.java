package com.example.healthprofile.entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    private Long id;

    @Column(nullable = false, unique = true)
    @Getter
    private String username;

    @Column(nullable = false)
    @Getter
    private String password;

    @Column(nullable = false, unique = true)
    @Getter
    private String email;

    @Column(name = "garminlogin")
    @Getter
    private String garminLogin;

    @Column(name = "garminpassword")
    @Getter
    private String garminPassword;

    @Column(name = "chatid")
    @Getter
    private Long chatId;

}

