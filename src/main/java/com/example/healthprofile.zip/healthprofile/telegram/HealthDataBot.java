package com.example.healthprofile.telegram;
import com.example.healthprofile.entity.HealthData;
import com.example.healthprofile.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import com.example.healthprofile.service.AuthService;
import com.example.healthprofile.repository.HealthDataRepository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.SignStyle;
import java.time.temporal.ChronoField;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class HealthDataBot extends TelegramLongPollingBot {
    public HealthDataBot(HealthDataRepository healthDataRepository) {
        this.healthDataRepository = healthDataRepository;
    }

    @Override
    public String getBotUsername() {
        return "DiaDataBot";
    }

    @Override
    public String getBotToken() {
        return "6583627596:AAHnA4nQyp45jcgmTQ42KYTIbL5iBR4yMiI";
    }

    @Autowired
    private AuthService authService;

    private Map<Long, Boolean> authenticatedUsers = new HashMap<>();
    private Map<Long, Long> userIds = new HashMap<>();
    private final HealthDataRepository healthDataRepository;

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {
            long chatId = update.getMessage().getChatId();
            String messageText = update.getMessage().getText();

            if (messageText.startsWith("/login")) {
                handleLogin(chatId, messageText);
            } else if (messageText.startsWith("/logout")) {
                handleLogout(chatId);
            } else if (messageText.startsWith("/myid")) {
                handleMyId(chatId);
            } else if (messageText.toLowerCase().startsWith("/add")) {
                handleAddHealthData(chatId, messageText.substring(5));  // Отрезаем '/add '
            } else if (messageText.toLowerCase().startsWith("/д") || messageText.toLowerCase().startsWith("/доб")) {
                handleAddHealthData(chatId, messageText.substring(3));  // Отрезаем '/д' или '/доб'
            }
        }
    }

    private void handleLogin(long chatId, String messageText) {
        String[] parts = messageText.split(" ");
        if (parts.length < 3) {
            sendTextMessage(chatId, "Чтобы войти используйте команду: /login <username> <password>");
            return;
        }
        String username = parts[1];
        String password = parts[2];

        User user = authService.authenticate(username, password);
        if (user != null) {
            authenticatedUsers.put(chatId, true);
            userIds.put(chatId, user.getId());
            sendTextMessage(chatId, "Вы успешно вошли");
        } else {
            sendTextMessage(chatId, "Неверное имя пользователя или пароль");
        }
    }

    private void handleLogout(long chatId) {
        authenticatedUsers.remove(chatId);
        userIds.remove(chatId);
        sendTextMessage(chatId, "Вы успешно вышли из аккаунта.");
    }

    private void handleMyId(long chatId) {
        if (isAuthenticated(chatId)) {
            Long userId = userIds.get(chatId);
            sendTextMessage(chatId, "Ваш ID: " + userId);
        } else {
            sendTextMessage(chatId, "Войдите, чтобы посмотреть ID.");
        }
    }

    private boolean isAuthenticated(long chatId) {
        return authenticatedUsers.getOrDefault(chatId, false);
    }

    private void sendTextMessage(long chatId, String text) {
        SendMessage message = new SendMessage();
        message.setChatId(String.valueOf(chatId));
        message.setText(text);
        try {
            execute(message);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private static final Pattern GLUCOSE_PATTERN = Pattern.compile("сахар\\s+(\\d+(\\.\\d+)?)");
    private static final Pattern INSULIN_PATTERN = Pattern.compile("инсулин\\s+(\\d+(\\.\\d+)?)");
    private static final Pattern CARBS_PATTERN = Pattern.compile("углеводы\\s+(\\d+(\\.\\d+)?)");
    private static final Pattern FOOD_PATTERN = Pattern.compile("еда\\s+(\\S+)");
    private static final Pattern DATE_PATTERN = Pattern.compile("дата\\s+(\\d{2}\\.\\d{2}\\.\\d{4})");
    private static final Pattern TIME_PATTERN = Pattern.compile("время\\s+(\\d{1,2}:\\d{2})");

    // Создаем DateTimeFormatter для парсинга времени в форматах "H:mm" и "HH:mm"
    private static final DateTimeFormatter TIME_FORMATTER = new DateTimeFormatterBuilder()
            .appendValue(ChronoField.HOUR_OF_DAY, 1, 2, SignStyle.NOT_NEGATIVE)
            .appendLiteral(':')
            .appendValue(ChronoField.MINUTE_OF_HOUR, 2)
            .toFormatter();

    public void handleAddHealthData(long chatId, String messageText) {
        if (!isAuthenticated(chatId)) {
            sendTextMessage(chatId, "Войдите, чтобы добавить запись.");
            return;
        }

        HealthData healthData = new HealthData();
        healthData.setUserId(userIds.get(chatId));
        healthData.setDate(LocalDate.now());
        healthData.setTime(LocalTime.now().withSecond(0).withNano(0)); // Устанавливаем время без секунд и миллисекунд

        Matcher glucoseMatcher = GLUCOSE_PATTERN.matcher(messageText);
        if (glucoseMatcher.find()) {
            healthData.setGlucoseLevel(Double.parseDouble(glucoseMatcher.group(1)));
        }

        Matcher insulinMatcher = INSULIN_PATTERN.matcher(messageText);
        if (insulinMatcher.find()) {
            healthData.setInsulinDose(Double.parseDouble(insulinMatcher.group(1)));
        }

        Matcher carbsMatcher = CARBS_PATTERN.matcher(messageText);
        if (carbsMatcher.find()) {
            healthData.setCarbohydrates(Double.parseDouble(carbsMatcher.group(1)));
        }

        Matcher foodMatcher = FOOD_PATTERN.matcher(messageText);
        if (foodMatcher.find()) {
            healthData.setFoodIntake(foodMatcher.group(1));
        }

        Matcher dateMatcher = DATE_PATTERN.matcher(messageText);
        if (dateMatcher.find()) {
            healthData.setDate(LocalDate.parse(dateMatcher.group(1), DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        }

        Matcher timeMatcher = TIME_PATTERN.matcher(messageText);
        if (timeMatcher.find()) {
            healthData.setTime(LocalTime.parse(timeMatcher.group(1), TIME_FORMATTER));
        }

        healthDataRepository.save(healthData);
        sendTextMessage(chatId, "Запись успешно добавлена.");
    }
}
