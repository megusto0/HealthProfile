package com.example.healthprofile.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;
@Entity
@Table(name = "garmin_data")
@Setter
public class GarminData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    private Long id;

    @Column(name = "date", nullable = false)
    @Getter
    private LocalDate date;

    @Column(name = "time", nullable = false)
    @Getter
    private LocalTime time;

    @Column(name = "heart_rate", nullable = false)
    @Getter
    private Integer heartRate;

    @Column(name = "user_id")
    @Getter
    private Long userId;  // предполагается, что у вас есть информация о пользователе
}
